from contextlib import contextmanager
import os
from pathlib import Path
from sqlalchemy import BigInteger, Boolean, DateTime, ForeignKey, Integer, String, Text, UniqueConstraint, text
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from datetime import datetime, timezone
from app.config import settings

class Base(DeclarativeBase): pass

class Instance(Base):
    __tablename__="instances"
    id: Mapped[int]=mapped_column(Integer, primary_key=True)
    name: Mapped[str]=mapped_column(String(80))
    bot_token: Mapped[str]=mapped_column(Text)
    customer_chat_id: Mapped[int]=mapped_column(BigInteger, default=0)
    state: Mapped[str]=mapped_column(String(30), default="STOPPED")
    validity_until: Mapped[datetime|None]=mapped_column(DateTime(timezone=True), nullable=True)
    log_chat_id: Mapped[int|None]=mapped_column(BigInteger, nullable=True)
    log_chat_title: Mapped[str|None]=mapped_column(String(255), nullable=True)
    log_chat_link: Mapped[str|None]=mapped_column(Text, nullable=True)
    disabled: Mapped[bool]=mapped_column(Boolean, default=False)
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class Account(Base):
    __tablename__="accounts"
    id: Mapped[int]=mapped_column(Integer, primary_key=True)
    instance_id: Mapped[int]=mapped_column(ForeignKey("instances.id"), unique=True)
    telegram_user_id: Mapped[int|None]=mapped_column(BigInteger, nullable=True)
    phone_hint: Mapped[str]=mapped_column(String(32), default="")
    session_path: Mapped[str]=mapped_column(Text)
    first_name: Mapped[str]=mapped_column(String(255), default="")
    username: Mapped[str]=mapped_column(String(255), default="")
    bio: Mapped[str]=mapped_column(Text, default="")
    authenticated: Mapped[bool]=mapped_column(Boolean, default=False)

class Campaign(Base):
    __tablename__="campaigns"
    id: Mapped[int]=mapped_column(Integer, primary_key=True)
    instance_id: Mapped[int]=mapped_column(ForeignKey("instances.id"))
    text: Mapped[str]=mapped_column(Text, default="")
    source_link: Mapped[str]=mapped_column(Text, default="")
    source_chat: Mapped[str]=mapped_column(Text, default="")
    source_message_id: Mapped[int|None]=mapped_column(Integer, nullable=True)
    target_category: Mapped[str]=mapped_column(String(20), default="ALL")
    media_path: Mapped[str|None]=mapped_column(Text, nullable=True)
    active: Mapped[bool]=mapped_column(Boolean, default=False)
    updated_at: Mapped[datetime]=mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class Destination(Base):
    __tablename__="destinations"
    id: Mapped[int]=mapped_column(Integer, primary_key=True)
    instance_id: Mapped[int]=mapped_column(ForeignKey("instances.id"))
    chat_id: Mapped[int|None]=mapped_column(BigInteger, nullable=True)
    username: Mapped[str]=mapped_column(String(255), default="")
    title: Mapped[str]=mapped_column(Text, default="")
    category: Mapped[str]=mapped_column(String(80), default="Custom")
    authorized: Mapped[bool]=mapped_column(Boolean, default=False)
    can_post: Mapped[bool]=mapped_column(Boolean, default=False)
    enabled: Mapped[bool]=mapped_column(Boolean, default=True)
    last_checked_at: Mapped[datetime|None]=mapped_column(DateTime(timezone=True), nullable=True)
    __table_args__=(UniqueConstraint("instance_id","chat_id",name="uq_instance_chat"),)

class QueueJob(Base):
    __tablename__="queue_jobs"
    id: Mapped[int]=mapped_column(Integer, primary_key=True)
    instance_id: Mapped[int]=mapped_column(ForeignKey("instances.id"))
    destination_id: Mapped[int]=mapped_column(ForeignKey("destinations.id"))
    status: Mapped[str]=mapped_column(String(20), default="PENDING")
    attempts: Mapped[int]=mapped_column(Integer, default=0)
    last_error: Mapped[str|None]=mapped_column(Text, nullable=True)

class Event(Base):
    __tablename__="events"
    id: Mapped[int]=mapped_column(Integer, primary_key=True)
    instance_id: Mapped[int|None]=mapped_column(Integer, nullable=True)
    level: Mapped[str]=mapped_column(String(20))
    event: Mapped[str]=mapped_column(String(60))
    detail: Mapped[str]=mapped_column(Text, default="")
    created_at: Mapped[datetime]=mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

_engine_kwargs = {"pool_pre_ping": True}
if settings.database_url.startswith("sqlite"):
    # WAL + busy timeout reduce cross-process SQLite contention when many
    # lightweight AdsGenie controllers share one local database.
    _engine_kwargs["connect_args"] = {"timeout": 30}
engine=create_async_engine(settings.database_url, **_engine_kwargs)
Session=async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

@contextmanager
def _db_init_lock():
    if not settings.database_url.startswith("sqlite"):
        yield
        return
    raw = settings.database_url.split("///", 1)[-1].split("?", 1)[0]
    db_file = Path(raw)
    if not db_file.is_absolute():
        from app.config import PROJECT_ROOT
        db_file = PROJECT_ROOT / db_file
    lock_path = db_file.with_suffix(db_file.suffix + ".init.lock")
    lock_path.parent.mkdir(parents=True, exist_ok=True)
    fh = open(lock_path, "a+b")
    try:
        if os.name == "nt":
            import msvcrt, time
            while True:
                try:
                    fh.seek(0)
                    msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
                    break
                except OSError:
                    time.sleep(0.1)
        else:
            import fcntl
            fcntl.flock(fh.fileno(), fcntl.LOCK_EX)
        yield
    finally:
        try:
            if os.name == "nt":
                import msvcrt
                fh.seek(0)
                msvcrt.locking(fh.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(fh.fileno(), fcntl.LOCK_UN)
        finally:
            fh.close()


async def _add_column_if_missing(conn, table, column, ddl):
    rows = await conn.execute(text(f"PRAGMA table_info({table})"))
    columns = {row[1] for row in rows.fetchall()}
    if column not in columns:
        await conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {ddl}"))


async def init_db():
    if settings.database_url.startswith("sqlite"):
        with _db_init_lock():
            async with engine.begin() as conn:
                await conn.execute(text("PRAGMA journal_mode=WAL"))
                await conn.execute(text("PRAGMA busy_timeout=30000"))
                await conn.run_sync(Base.metadata.create_all)
                await _add_column_if_missing(conn, "instances", "log_chat_id", "log_chat_id BIGINT")
                await _add_column_if_missing(conn, "instances", "log_chat_title", "log_chat_title TEXT")
                await _add_column_if_missing(conn, "instances", "log_chat_link", "log_chat_link TEXT")
                await _add_column_if_missing(conn, "campaigns", "source_link", "source_link TEXT DEFAULT ''")
                await _add_column_if_missing(conn, "campaigns", "source_chat", "source_chat TEXT DEFAULT ''")
                await _add_column_if_missing(conn, "campaigns", "source_message_id", "source_message_id INTEGER")
                await _add_column_if_missing(conn, "campaigns", "target_category", "target_category TEXT DEFAULT 'ALL'")
                await _add_column_if_missing(conn, "destinations", "last_checked_at", "last_checked_at DATETIME")
    else:
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
