import argparse
import asyncio
import sys


def main():
    # Keep manager commands lightweight: do not import DB/CLI until needed.
    if len(sys.argv) >= 4 and sys.argv[1] == "manager":
        from app.process_manager import start, stop, status, tail
        action = sys.argv[2]
        try:
            iid = int(sys.argv[3])
        except ValueError:
            raise SystemExit("INSTANCE must be an integer")
        if iid <= 0:
            raise SystemExit("INSTANCE must be > 0")
        if action == "start":
            start(iid)
        elif action == "stop":
            stop(iid)
        elif action == "status":
            status(iid)
        elif action == "logs":
            tail(iid)
        else:
            raise SystemExit("manager action: start|stop|status|logs")
        return

    from app.config import settings

    p = argparse.ArgumentParser(description="AdsGenie multi-tenant control plane")
    p.add_argument(
        "command",
        nargs="?",
        default="menu",
        choices=["menu", "preflight", "db-init", "bot", "login", "sync", "logs-repair"],
    )
    p.add_argument("--instance", type=int)
    args = p.parse_args()

    if args.instance:
        settings.instance_id = args.instance

    if args.command == "preflight":
        print("=== AdsGenie preflight ===")
        print("Config:", "OK" if settings.required_ok() else "MISSING")
        print("Max instances:", settings.max_instances)
        print("Database:", settings.database_url)
        return

    if args.command == "db-init":
        from app.db import init_db
        asyncio.run(init_db())
        print("Database initialized.")
        return

    if args.command == "login":
        from app.mtproto.auth import login_instance
        asyncio.run(login_instance(settings.instance_id))
        return

    if args.command == "sync":
        from app.mtproto.targets import sync_targets
        asyncio.run(sync_targets(settings.instance_id))
        return

    if args.command == "logs-repair":
        if not args.instance:
            raise SystemExit("Logs repair requires --instance N")
        from app.bots.controller import repair_logs_channel
        try:
            result = asyncio.run(repair_logs_channel(args.instance))
        except Exception as exc:
            raise SystemExit(f"Logs repair failed: {type(exc).__name__}: {exc}")
        print("Logs channel READY")
        print("Title:", result["title"])
        print("Chat ID:", result["chat_id"])
        print("Link:", result["link"] or "No invite link returned")
        return

    if args.command == "bot":
        if not args.instance:
            raise SystemExit("Controller bot requires --instance N")
        from app.bots.controller import run_controller
        asyncio.run(run_controller(args.instance))
        return

    from app.cli import interactive
    asyncio.run(interactive())


if __name__ == "__main__":
    main()
