import os
import signal
import subprocess
import sys
import time
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
RUN_DIR = BASE / "runtime"
RUN_DIR.mkdir(exist_ok=True)
SYSTEMD_UNIT = "adsgenie-instance@.service"
SYSTEMD_PATH = Path("/etc/systemd/system") / SYSTEMD_UNIT


def _systemd_available() -> bool:
    return os.name != "nt" and SYSTEMD_PATH.exists() and bool(__import__("shutil").which("systemctl"))


def _systemd(action: str, instance_id: int, enable: bool = False):
    unit = f"adsgenie-instance@{int(instance_id)}.service"
    cmd = ["systemctl"]
    if action == "start" and enable:
        cmd += ["enable", "--now", unit]
    elif action == "stop":
        cmd += ["stop", unit]
    elif action == "restart":
        cmd += ["restart", unit]
    elif action == "status":
        cmd += ["is-active", unit]
    else:
        cmd += [action, unit]
    return __import__("subprocess").run(cmd, stdout=__import__("subprocess").PIPE, stderr=__import__("subprocess").STDOUT, text=True, check=False)



def pid_file(instance_id: int) -> Path:
    return RUN_DIR / f"controller_{instance_id}.pid"


def log_file(instance_id: int) -> Path:
    return RUN_DIR / f"controller_{instance_id}.log"


def _is_alive(pid: int) -> bool:
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, PermissionError):
        return False
    except OSError:
        return False


def read_pid(instance_id: int):
    p = pid_file(instance_id)
    if not p.exists():
        return None
    try:
        pid = int(p.read_text(encoding="utf-8").strip())
    except (ValueError, OSError):
        try:
            p.unlink()
        except OSError:
            pass
        return None
    if _is_alive(pid):
        return pid
    try:
        p.unlink()
    except OSError:
        pass
    return None


def _cleanup_stale_pid(instance_id: int):
    try:
        pid_file(instance_id).unlink()
    except OSError:
        pass


def start(instance_id: int):
    if _systemd_available():
        result = _systemd("start", instance_id, enable=True)
        if result.returncode == 0:
            print(f"Controller #{instance_id:02d} started with systemd (24/7).")
            return True
        print(f"systemd start failed for #{instance_id:02d}; falling back to background process.")
        if result.stdout:
            print(result.stdout.strip())
    existing = read_pid(instance_id)
    if existing:
        print(f"Controller #{instance_id:02d} is already running (PID {existing}).")
        return False

    lp = log_file(instance_id)
    with lp.open("a", encoding="utf-8") as out:
        out.write(f"\n--- controller start {time.strftime('%Y-%m-%d %H:%M:%S')} ---\n")
        out.flush()

        env = os.environ.copy()
        env["PYTHONUNBUFFERED"] = "1"
        cmd = [
            sys.executable,
            str(BASE / "run.py"),
            "bot",
            "--instance",
            str(instance_id),
        ]

        creationflags = 0
        if os.name == "nt":
            # Keep the controller independent from the interactive CLI window.
            creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)

        proc = subprocess.Popen(
            cmd,
            cwd=str(BASE),
            stdin=subprocess.DEVNULL,
            stdout=out,
            stderr=subprocess.STDOUT,
            start_new_session=(os.name != "nt"),
            creationflags=creationflags,
            env=env,
        )

    pid_file(instance_id).write_text(str(proc.pid), encoding="utf-8")

    # Do not lie to the operator: verify the child survives startup.
    time.sleep(1.25)
    if proc.poll() is not None:
        _cleanup_stale_pid(instance_id)
        try:
            tail = lp.read_text(encoding="utf-8", errors="replace").splitlines()[-25:]
        except OSError:
            tail = []
        print(f"Controller #{instance_id:02d} FAILED during startup (exit code {proc.returncode}).")
        if tail:
            print("----- controller log -----")
            print("\n".join(tail))
            print("----- end log -----")
        return False

    print(f"Controller #{instance_id:02d} started in background. PID: {proc.pid}")
    print(f"Log: {lp}")
    return True


def stop(instance_id: int):
    if _systemd_available():
        result = _systemd("stop", instance_id)
        if result.returncode == 0:
            _cleanup_stale_pid(instance_id)
            print(f"Controller #{instance_id:02d} stopped.")
            return True
    pid = read_pid(instance_id)
    if not pid:
        print(f"Controller #{instance_id:02d} is not running.")
        return False

    try:
        if os.name == "nt":
            # CTRL_BREAK requires a console; fall back to terminate for a detached child.
            os.kill(pid, signal.SIGTERM)
        else:
            os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:
        pass
    except OSError as exc:
        print(f"Could not stop controller #{instance_id:02d}: {exc}")
        return False

    # Give the process a moment, then force-kill only if still alive.
    time.sleep(0.5)
    if _is_alive(pid):
        try:
            if os.name == "nt":
                subprocess.run(
                    ["taskkill", "/PID", str(pid), "/T", "/F"],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    check=False,
                )
            else:
                os.kill(pid, signal.SIGKILL)
        except OSError:
            pass

    _cleanup_stale_pid(instance_id)
    print(f"Controller #{instance_id:02d} stopped.")
    return True


def status(instance_id: int):
    if _systemd_available():
        result = _systemd("status", instance_id)
        if result.returncode == 0:
            print(f"Controller #{instance_id:02d}: RUNNING (systemd)")
            return True
        print(f"Controller #{instance_id:02d}: STOPPED")
        return False
    pid = read_pid(instance_id)
    if pid:
        print(f"Controller #{instance_id:02d}: RUNNING (PID {pid})")
        return True
    print(f"Controller #{instance_id:02d}: STOPPED")
    return False


def tail(instance_id: int, lines=60):
    p = log_file(instance_id)
    if not p.exists():
        print("No controller log yet.")
        return
    data = p.read_text(encoding="utf-8", errors="replace").splitlines()
    print("\n".join(data[-lines:]))


def start_all(instance_ids):
    return all(start(iid) for iid in instance_ids)
