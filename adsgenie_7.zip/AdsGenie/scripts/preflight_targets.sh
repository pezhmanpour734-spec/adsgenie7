#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ ! -x .venv/bin/python ]]; then
  echo "Missing .venv. Create it and install requirements first." >&2
  exit 1
fi
.venv/bin/python run.py
