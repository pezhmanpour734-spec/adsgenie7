from pathlib import Path
from types import SimpleNamespace

from app.services.forum_topics import select_forum_topic_id
from app.target_list import load_target_usernames


def test_forum_prefers_open_instagram_topic():
    topics = [
        SimpleNamespace(id=1, title="General", closed=False, hidden=False),
        SimpleNamespace(id=8, title="Instagram Promo", closed=False, hidden=False),
        SimpleNamespace(id=9, title="Instagram old", closed=True, hidden=False),
    ]
    assert select_forum_topic_id(topics) == 8


def test_forum_falls_back_to_general_then_first_open():
    assert select_forum_topic_id([
        SimpleNamespace(id=1, title="General", closed=False, hidden=False),
        SimpleNamespace(id=2, title="Other", closed=False, hidden=False),
    ]) == 1
    assert select_forum_topic_id([
        SimpleNamespace(id=4, title="Other", closed=False, hidden=False),
        SimpleNamespace(id=5, title="Hidden", closed=False, hidden=True),
    ]) == 4
    assert select_forum_topic_id([SimpleNamespace(id=1, title="General", closed=True, hidden=False)]) is None


def test_target_list_supports_handles_links_and_case_insensitive_dedup(tmp_path):
    target_file = tmp_path / "targets.txt"
    target_file.write_text("@ExampleHandle\nhttps://t.me/examplehandle\nhttps://t.me/AnotherHandle\n# comment\n", encoding="utf-8")
    assert load_target_usernames(target_file) == {"examplehandle", "anotherhandle"}


def test_bundled_target_list_contains_combined_unique_destinations():
    path = Path("targets.txt")
    handles = [line.strip()[1:] for line in path.read_text(encoding="utf-8").splitlines() if line.strip() and not line.startswith("#")]
    assert len(handles) == 273
    assert len({handle.casefold() for handle in handles}) == len(handles)
