"""Pure forum-topic selection helpers (no Telegram/network dependencies)."""

def select_forum_topic_id(items):
    """Choose an open topic: Instagram title, General, then first open topic."""
    open_topics = [
        topic for topic in list(items or [])
        if not bool(getattr(topic, "closed", False))
        and not bool(getattr(topic, "hidden", False))
        and getattr(topic, "id", None) is not None
    ]
    if not open_topics:
        return None
    instagram = next((
        topic for topic in open_topics
        if "instagram" in str(getattr(topic, "title", "") or "").casefold()
    ), None)
    general = next((topic for topic in open_topics if int(getattr(topic, "id", 0)) == 1), None)
    selected = instagram or general or open_topics[0]
    return int(getattr(selected, "id"))
