from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CLI = (ROOT / "app" / "cli.py").read_text(encoding="utf-8")
CTRL = (ROOT / "app" / "bots" / "controller.py").read_text(encoding="utf-8")


def test_cli_has_token_chatid_and_validity_management():
    assert "12. Edit instance / token / Chat ID / validity" in CLI
    assert "Change bot token" in CLI
    assert "Change customer Chat ID" in CLI
    assert "Assign / renew validity" in CLI
    for days in (7, 30, 45, 60, 90, 180, 365):
        assert f"{days}" in CLI


def test_bot_token_is_validated_before_save():
    assert "await _validate_bot_token(token)" in CLI
    assert "Telegram rejected the bot token" in CLI


def test_customer_access_checks_disabled_and_expiry():
    assert "fresh.disabled" in CTRL
    assert "ACCESS EXPIRED" in CTRL
    assert "datetime.now(timezone.utc)" in CTRL


def test_validity_reports_remaining_time():
    assert "Remaining:" in CTRL
    assert "Expires:" in CTRL
